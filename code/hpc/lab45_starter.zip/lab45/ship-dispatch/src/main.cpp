#include "Dispatch.hpp"
#include "benchmark/benchmark.h"

static void BM_DispShip(benchmark::State& state)
{
    const auto num_orders = state.range(0);
    const auto order_size = state.range(1);
    auto       orders     = std::vector< Order >{};
    orders.reserve(num_orders);
    for (int i = 0; i != num_orders; ++i)
        orders.push_back(Order::random(order_size));

    for (auto _ : state)
    {
        const auto shipments = dispatch(orders);
        benchmark::DoNotOptimize(shipments.data());
        benchmark::ClobberMemory();
    }
}

BENCHMARK(BM_DispShip)->Name("Dispatch shipments")->UseRealTime()->Unit(benchmark::kSecond)->Args({10'000, 40'000});
BENCHMARK_MAIN();
