#include <algorithm>
#include <random>
#include <vector>

struct Parcel
{
    size_t id;
    double x, y, z;
    double wgt;

    static Parcel random()
    {
        static auto id_counter = 0uz;
        static auto prng       = std::mt19937{};
        auto        vol_dist   = std::uniform_real_distribution< double >{.2, .8};
        auto        wgt_dist   = std::uniform_real_distribution< double >{1., 10.};
        return {
            .id = id_counter++, .x = vol_dist(prng), .y = vol_dist(prng), .z = vol_dist(prng), .wgt = wgt_dist(prng)};
    }
};

struct Order
{
    std::vector< Parcel > parcels;
    size_t                dest_id;

    static Order random(size_t size)
    {
        static auto prng    = std::mt19937{};
        auto        parcels = std::vector< Parcel >{};
        parcels.reserve(size);
        for (size_t i = 0; i != size; ++i)
            parcels.push_back(Parcel::random());
        std::ranges::shuffle(parcels, prng);
        return {.parcels = std::move(parcels), .dest_id = prng()};
    }
};

struct Shipment
{
    size_t                dest;
    std::vector< size_t > parcels;
};

inline constexpr double truck_volume_capacity = 20.;
inline constexpr double truck_wgt_capacity    = 1000.;
