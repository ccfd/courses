#include "Structs.hpp"

auto dispatch(const std::vector< Order >& orders) -> std::vector< Shipment >
{
    auto retval = std::vector< Shipment >{};
    for (const auto& [parcels, dest_id] : orders)
    {
        Shipment s{.dest = dest_id, .parcels = {}};
        double   wgt = 0.;
        double   vol = 0.;
        for (const auto& [id, x, y, z, pw] : parcels)
        {
            const auto pv = x * y * z;
            if (wgt + pw <= truck_wgt_capacity and vol + pv <= truck_volume_capacity)
            {
                s.parcels.push_back(id);
                wgt += pw;
                vol += pv;
            }
            else
            {
                retval.push_back(std::move(s));
                s = {.dest = dest_id, .parcels = {}};
                s.parcels.push_back(id);
                wgt = pw;
                vol = pv;
            }
        }
        retval.push_back(std::move(s));
    }
    return retval;
}