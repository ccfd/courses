#include <array>
#include <vector>

struct Mesh
{
    std::vector< std::array< unsigned, 2 > > topology;
    std::vector< double >                    x, y;
};

// Generate an example mesh describing a 2D truss.
// In this example, the nodes are distributed on a cartesian grid, the topology
// of the mesh is as follows:
/*
 * o-o-o-o-o-o  ^
 * |\|\|\|\|\|  |
 * o-o-o-o-o-o  |  n_nodes_y layers
 * |\|\|\|\|\|  |
 * o-o-o-o-o-o  |
 *
 * ----------->
 * n_nodes_x layers
 *
 */
auto generateMesh(unsigned n_nodes_x, unsigned n_nodes_y) -> Mesh;
