#include "GenerateMesh.hpp"
#include "MakeRandomVector.hpp"

#include "benchmark/benchmark.h"

#include <algorithm>
#include <cmath>

auto computeLocalProduct(const std::array< double, 4 >& coords, const std::array< double, 4 >& lhs_local)
    -> std::array< double, 4 >
{
    const auto [x1, y1, x2, y2] = coords;
    const auto dx               = x2 - x1;
    const auto dy               = y2 - y1;
    const auto dx2              = dx * dx;
    const auto dy2              = dy * dy;
    const auto dxdy             = dx * dy;

    std::array< std::array< double, 4 >, 4 > K;
    K[0][0] = dx2;
    K[0][1] = dxdy;
    K[0][2] = -dx2;
    K[0][3] = -dxdy;
    K[1][0] = dxdy;
    K[1][1] = dy2;
    K[1][2] = -dxdy;
    K[1][3] = -dy2;
    for (unsigned c = 2; c < 4; ++c)
        for (unsigned r = 0; r < 4; ++r)
            K[c][r] = -K[c - 2][r];

    std::array< double, 4 > mult_result{};
    for (unsigned c = 0; c < 4; ++c)
        for (unsigned r = 0; r < 4; ++r)
            mult_result[r] += K[c][r] * lhs_local[c];

    const auto     L = std::sqrt(dx2 + dy2);
    constexpr auto E = 210e9;
    constexpr auto A = 3.14 * 1e-2 * 1e-2;
    const auto     C = E * A / (L * L * L);
    for (auto& a : mult_result)
        a *= C;

    return mult_result;
}

auto computeDofs(unsigned n1, unsigned n2) -> std::array< unsigned, 4 >
{
    return std::array{n1 * 2, n1 * 2 + 1, n2 * 2, n2 * 2 + 1};
}

auto gatherGlobal(unsigned n1, unsigned n2, const std::vector< double >& rhs_global) -> std::array< double, 4 >
{
    const auto dofs = computeDofs(n1, n2);
    return std::array{rhs_global[dofs[0]], rhs_global[dofs[1]], rhs_global[dofs[2]], rhs_global[dofs[3]]};
}

void scatterLocal(unsigned n1, unsigned n2, const std::array< double, 4 >& vals, std::vector< double >& rhs_global)
{
    const auto dofs = computeDofs(n1, n2);
    for (unsigned i = 0; i < dofs.size(); ++i)
        rhs_global[dofs[i]] += vals[i];
}

// Local contribution of the element described by the nodes (n1, n2)
void processsElement(unsigned                     n1,
                     unsigned                     n2,
                     const std::vector< double >& x,
                     const std::vector< double >& y,
                     const std::vector< double >& lhs,
                     std::vector< double >&       rhs)
{
    const auto lhs_vals   = gatherGlobal(n1, n2, lhs);
    const auto coords     = std::array{x[n1], y[n1], x[n2], y[n2]};
    const auto local_prod = computeLocalProduct(coords, lhs_vals);
    scatterLocal(n1, n2, local_prod, rhs);
}

void solution(const Mesh& mesh, const std::vector< double >& lhs, std::vector< double >& rhs)
{
    const auto& [topo, x, y] = mesh;
    std::ranges::fill(rhs, 0.);
    for (auto [n1, n2] : topo)
        processsElement(n1, n2, x, y, lhs, rhs);
}

static void BM_truss_mf(benchmark::State& state)
{
    // Mesh
    constexpr unsigned n_nodes_x = 1'000, n_nodes_y = 20'000, n_nodes = n_nodes_x * n_nodes_y;
    const auto         mesh = generateMesh(n_nodes_x, n_nodes_y);

    // Generate random left-hand side
    const auto lhs = makeRandomVector< double >(2 * n_nodes);

    // Right-hand side
    auto rhs = std::vector< double >(2 * n_nodes);

    // Run the benchmark
    for (auto _ : state)
    {
        solution(mesh, lhs, rhs);
        benchmark::DoNotOptimize(rhs.data());
        benchmark::ClobberMemory();
    }
    state.counters["Element processing rate"] = benchmark::Counter{
        static_cast< double >(state.iterations() * mesh.topology.size()), benchmark::Counter::kIsRate};
}

BENCHMARK(BM_truss_mf)->Name("Apply matrix-free operator")->UseRealTime()->Unit(benchmark::kSecond);
BENCHMARK_MAIN();
