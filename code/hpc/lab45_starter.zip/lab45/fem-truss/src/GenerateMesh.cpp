#include "GenerateMesh.hpp"

auto generateMesh(unsigned n_nodes_x, unsigned n_nodes_y) -> Mesh
{
    const unsigned n_nodes = n_nodes_x * n_nodes_y;

    auto retval            = Mesh{};
    auto& [topology, x, y] = retval;

    // Topo
    topology.reserve((n_nodes_x - 1) * (n_nodes_y - 1) * 3 + (n_nodes_x - 1) + (n_nodes_y - 1));
    for (unsigned j = 0; j < n_nodes_y - 1; ++j)
    {
        for (unsigned i = 0; i < n_nodes_x - 1; ++i)
        {
            const unsigned base = n_nodes_x * j + i;
            topology.push_back(std::array< unsigned, 2 >{base, base + 1});
            topology.push_back(std::array< unsigned, 2 >{base, base + n_nodes_x});
            topology.push_back(std::array< unsigned, 2 >{base, base + n_nodes_x + 1});
        }
        topology.push_back(std::array< unsigned, 2 >{n_nodes_x * (j + 1) - 1, n_nodes_x * (j + 2) - 1});
    }
    for (unsigned i = 0; i < n_nodes_x - 1; ++i)
        topology.push_back(
            std::array< unsigned, 2 >{n_nodes_x * (n_nodes_y - 1) + i, n_nodes_x * (n_nodes_y - 1) + i + 1});

    // Coords
    x.resize(n_nodes);
    y.resize(n_nodes);
    unsigned coord_ind = 0;
    for (unsigned j = 0; j < n_nodes_y; ++j)
        for (unsigned i = 0; i < n_nodes_x; ++i)
        {
            x[coord_ind] = i;
            y[coord_ind] = j;
            ++coord_ind;
        }

    return retval;
}
