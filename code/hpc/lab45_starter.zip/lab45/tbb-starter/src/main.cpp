#include "MakeRandomVector.hpp"

#include "benchmark/benchmark.h"
#include "tbb/tbb.h"

#include <algorithm>
#include <cmath>

static void BM_serial(benchmark::State& state)
{
    const int size = state.range(0);
    auto      v    = makeRandomVector(size, 0., 1.);
    for (auto _ : state)
    {
        for (int i = 0; i < v.size(); ++i)
            v[i] = sin(v[i]);
        benchmark::DoNotOptimize(v.data());
        benchmark::ClobberMemory();
    }
    state.SetBytesProcessed(state.iterations() * size * sizeof(double));
}
BENCHMARK(BM_serial)->Name("Serial benchmark")->Range(100, 1000000)->UseRealTime();

BENCHMARK_MAIN();
