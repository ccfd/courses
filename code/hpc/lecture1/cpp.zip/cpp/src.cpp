#include "benchmark/benchmark.h"
#include "mkl.h"
#include "oneapi/tbb.h"

#include <array>
#include <functional>
#include <memory>
#include <random>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Utils
auto allocateArray(size_t size) -> std::unique_ptr< double[] >
{
    return std::unique_ptr< double[] >{new (std::align_val_t{4096}) double[size]};
}
auto makeZeroArray(size_t size) -> std::unique_ptr< double[] >
{
    auto retval = allocateArray(size);
    std::fill_n(retval.get(), size, 0.);
    return retval;
}
auto makeRandomArray(size_t size) -> std::unique_ptr< double[] >
{
    auto retval = allocateArray(size);
    std::generate_n(retval.get(), size, [prng = std::mt19937{std::random_device{}()}]() mutable {
        return std::uniform_real_distribution< double >{-1., 1.}(prng);
    });
    return retval;
}
void nukeCache()
{
    const size_t nuke_size = 1 << 30;
    const auto   alloc     = std::make_unique_for_overwrite< volatile char[] >(nuke_size);
    std::fill_n(alloc.get(), nuke_size, 0);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Inputs
static constexpr size_t N = 1 << 12;
static const auto       a = makeRandomArray(N * N), b = makeRandomArray(N * N);
template < typename T >
static auto colMajAccess(T* ptr, size_t row, size_t col)
{
    return ptr + row + col * N;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Baseline: serial triple-nested for loop
static void BM_baseline(benchmark::State& state)
{
    const auto c = makeZeroArray(N * N);
    for (auto _ : state)
    {
        state.PauseTiming();
        std::fill_n(c.get(), N * N, 0.);
        nukeCache();
        state.ResumeTiming();
        for (size_t col = 0; col != N; ++col)
            for (size_t k = 0; k != N; ++k)
                for (size_t row = 0; row != N; ++row)
                    c[row + col * N] += a[row + k * N] * b[k + col * N];
        benchmark::DoNotOptimize(c.get());
        benchmark::ClobberMemory();
    }
    state.counters["DPFlops"] = benchmark::Counter{static_cast< double >(state.iterations() * N * N * N * 2),
                                                   benchmark::Counter::kIsRate,
                                                   benchmark::Counter::kIs1000};
}
BENCHMARK(BM_baseline)->Name("Baseline")->Unit(benchmark::kSecond)->Repetitions(10)->UseRealTime();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tiled approach, sequential
static void BM_tiled_seq(benchmark::State& state)
{
    static constexpr size_t tile_size = 32;
    const auto              c         = makeZeroArray(N * N);
    for (auto _ : state)
    {
        state.PauseTiming();
        std::fill_n(c.get(), N * N, 0.);
        nukeCache();
        state.ResumeTiming();
        for (size_t tile_col = 0; tile_col != N; tile_col += tile_size)
            for (size_t tile_k = 0; tile_k != N; tile_k += tile_size)
                for (size_t tile_row = 0; tile_row != N; tile_row += tile_size)
                    for (size_t col = 0; col != tile_size; ++col)
                        for (size_t k = 0; k != tile_size; ++k)
                            for (size_t row = 0; row != tile_size; ++row)
                                c[row + tile_row + (col + tile_col) * N] +=
                                    a[row + tile_row + (k + tile_k) * N] * b[k + tile_k + (col + tile_col) * N];
        benchmark::DoNotOptimize(c.get());
        benchmark::ClobberMemory();
    }
    state.counters["DPFlops"] = benchmark::Counter{static_cast< double >(state.iterations() * N * N * N * 2),
                                                   benchmark::Counter::kIsRate,
                                                   benchmark::Counter::kIs1000};
}
BENCHMARK(BM_tiled_seq)->Name("Tiled, sequential")->Unit(benchmark::kSecond)->Repetitions(10)->UseRealTime();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tiled approach, parallel
static void BM_tiled_par(benchmark::State& state)
{
    static constexpr size_t tile_size = 32;
    const auto              c         = makeZeroArray(N * N);
    for (auto _ : state)
    {
        state.PauseTiming();
        std::fill_n(c.get(), N * N, 0.);
        nukeCache();
        state.ResumeTiming();
        const auto tile_col_range = oneapi::tbb::blocked_range< size_t >{0, N / tile_size};
        oneapi::tbb::parallel_for(tile_col_range, [&](const oneapi::tbb::blocked_range< size_t >& tc_block) {
            const auto tc_begin = tc_block.begin() * tile_size, tc_end = tc_block.end() * tile_size;
            for (size_t tile_col = tc_begin; tile_col != tc_end; tile_col += tile_size)
                for (size_t tile_k = 0; tile_k != N; tile_k += tile_size)
                    for (size_t tile_row = 0; tile_row != N; tile_row += tile_size)
                        for (size_t col = 0; col != tile_size; ++col)
                            for (size_t k = 0; k != tile_size; ++k)
                                for (size_t row = 0; row != tile_size; ++row)
                                    c[row + tile_row + (col + tile_col) * N] +=
                                        a[row + tile_row + (k + tile_k) * N] * b[k + tile_k + (col + tile_col) * N];
        });
        benchmark::DoNotOptimize(c.get());
        benchmark::ClobberMemory();
    }
    state.counters["DPFlops"] = benchmark::Counter{static_cast< double >(state.iterations() * N * N * N * 2),
                                                   benchmark::Counter::kIsRate,
                                                   benchmark::Counter::kIs1000};
}
BENCHMARK(BM_tiled_par)->Name("Tiled, parallel")->Unit(benchmark::kSecond)->Repetitions(10)->UseRealTime();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Intel MKL
static void BM_MKL(benchmark::State& state)
{
    const auto c = makeZeroArray(N * N);
    for (auto _ : state)
    {
        state.PauseTiming();
        std::fill_n(c.get(), N * N, 0.);
        nukeCache();
        state.ResumeTiming();
        cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, N, N, N, 1., a.get(), N, b.get(), N, 0., c.get(), N);
        benchmark::DoNotOptimize(c.get());
        benchmark::ClobberMemory();
    }
    state.counters["DPFlops"] = benchmark::Counter{static_cast< double >(state.iterations() * N * N * N * 2),
                                                   benchmark::Counter::kIsRate,
                                                   benchmark::Counter::kIs1000};
}
BENCHMARK(BM_MKL)->Unit(benchmark::kMillisecond)->Name("MKL")->Repetitions(10)->UseRealTime();

BENCHMARK_MAIN();
