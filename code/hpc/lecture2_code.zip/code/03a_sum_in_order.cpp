#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"

#include <algorithm>

void BM_acc_in_order(benchmark::State& state)
{
    const size_t                  size = state.range(0);
    const auto                    vals = makeRandomVector< double >(size);
    std::vector< std::ptrdiff_t > inds(size);
    std::iota(inds.begin(), inds.end(), 0);

    for (auto _ : state)
    {
        double acc = 0.;
        for (auto i : inds)
            acc += vals[i];
        benchmark::DoNotOptimize(acc);
    }
    state.SetBytesProcessed(state.iterations() * size * sizeof(double));
}
BENCHMARK(BM_acc_in_order)->Arg(1 << 13)->Arg(1 << 20);

BENCHMARK_MAIN();
