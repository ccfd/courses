#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"

#include <algorithm>

void BM_memcpy(benchmark::State& state)
{
    const size_t size = state.range(0);
    const auto   src  = makeRandomVector< double >(size);
    auto         dest = src;

    for (auto _ : state)
    {
        std::ranges::copy(src, dest.begin());
        benchmark::DoNotOptimize(dest.data());
        benchmark::ClobberMemory();
    }
    state.SetBytesProcessed(state.iterations() * size * sizeof(double));
}
BENCHMARK(BM_memcpy)->RangeMultiplier(2)->Range(1, 1ul << 28);

BENCHMARK_MAIN();
