#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"

void BM_branch_predicted(benchmark::State& state)
{
    const size_t size = state.range(0);
    const auto   pred = std::vector< int >(size, 1);
    const auto   val  = makeRandomVector< int >(size);

    for (auto _ : state)
    {
        int acc = 0;
        for (int i = 0; i < size; ++i)
            if (pred[i])
                acc += val[i];
        benchmark::DoNotOptimize(acc);
    }
    state.SetBytesProcessed(state.iterations() * size * sizeof(int));
}
BENCHMARK(BM_branch_predicted)->Arg(1 << 20);

BENCHMARK_MAIN();
