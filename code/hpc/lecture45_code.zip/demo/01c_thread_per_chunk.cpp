#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"

#include <algorithm>
#include <ranges>
#include <thread>

void BM_thread_per_chunk(benchmark::State &state) {
  const auto input = makeRandomVectorOfStrings(state.range(0), state.range(1));
  auto output = std::vector<size_t>(input.size());
  constexpr int num_threads = 16;
  auto threads = std::vector<std::thread>(num_threads);
  const int chunk_size = input.size() / num_threads;
  for (auto _ : state) {
    for (auto &&[i, thr] : threads | std::views::enumerate)
      thr = std::thread{[&, i] {
        std::ranges::transform(input | std::views::drop(i * chunk_size) |
                                   std::views::take(chunk_size),
                               std::next(output.begin(), i * chunk_size),
                               std::hash<std::string>{});
      }};
    for (auto &thr : threads)
      thr.join();
    benchmark::DoNotOptimize(output.data());
    benchmark::ClobberMemory();
  }
  if (!std::ranges::equal(
          output, input | std::views::transform(std::hash<std::string>{})))
    throw std::runtime_error{"Incorrect result"};
  state.SetBytesProcessed(state.range(0) * state.range(1) * state.iterations());
}
BENCHMARK(BM_thread_per_chunk)
    ->UseRealTime()
    ->RangeMultiplier(4)
    ->Ranges({{1 << 8, 1 << 14}, {1 << 8, 1 << 14}});
BENCHMARK_MAIN();
