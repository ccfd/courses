#include "benchmark/benchmark.h"

#include <atomic>

void BM_inc_atomic(benchmark::State &state) {
  const int n = state.range(0);
  for (auto _ : state) {
    std::atomic<unsigned> a{0};
    for (int i = 0; i != n; ++i)
      a.fetch_add(1, std::memory_order_relaxed);
    benchmark::DoNotOptimize(a);
  }
  state.counters["increments"] = benchmark::Counter{
      static_cast<double>(state.iterations()) * n, benchmark::Counter::kIsRate,
      benchmark::Counter::kIs1000};
}
BENCHMARK(BM_inc_atomic)->Arg(1 << 12);
BENCHMARK_MAIN();
