#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"

#include <ranges>
#include <thread>

void BM_thread_per_string(benchmark::State &state) {
  const auto input = makeRandomVectorOfStrings(state.range(0), state.range(1));
  auto output = std::vector<size_t>(input.size());
  auto threads = std::vector<std::thread>(input.size());
  const auto hash = std::hash<std::string>{};
  for (auto _ : state) {
    for (auto &&[in, out, thr] : std::views::zip(input, output, threads))
      thr = std::thread{[&] { out = hash(in); }};
    for (auto &thr : threads)
      thr.join();
    benchmark::DoNotOptimize(output.data());
    benchmark::ClobberMemory();
  }
  state.SetBytesProcessed(state.range(0) * state.range(1) * state.iterations());
}
BENCHMARK(BM_thread_per_string)
    ->UseRealTime()
    ->RangeMultiplier(4)
    ->Ranges({{1 << 8, 1 << 14}, {1 << 8, 1 << 14}});
BENCHMARK_MAIN();
