#include "benchmark/benchmark.h"
#include "oneapi/tbb.h"

#include <atomic>

void BM_inc_par(benchmark::State &state) {
  const auto max_threads = state.range(0);
  const auto guard = oneapi::tbb::global_control{
      oneapi::tbb::global_control::max_allowed_parallelism, max_threads};
  const int n = 1 << 24;
  const auto range = oneapi::tbb::blocked_range<int>{0, n};
  for (auto _ : state) {
    std::atomic<unsigned> a{0};
    oneapi::tbb::parallel_for(range, [&a](const auto &r) {
      for (int i = r.begin(); i != r.end(); ++i)
        ++a;
    });
    benchmark::DoNotOptimize(a);
  }
  state.counters["increments"] = benchmark::Counter{
      static_cast<double>(state.iterations()) * n, benchmark::Counter::kIsRate,
      benchmark::Counter::kIs1000};
}
BENCHMARK(BM_inc_par)->UseRealTime()->RangeMultiplier(2)->Range(1, 16);
BENCHMARK_MAIN();
