#include <algorithm>
#include <concepts>
#include <limits>
#include <random>
#include <string>
#include <vector>

namespace detail {
template <typename T>
  requires std::floating_point<T> || std::integral<T>
struct rand_dist {};

template <std::integral T> struct rand_dist<T> {
  using type = std::uniform_int_distribution<T>;
};

template <std::floating_point T> struct rand_dist<T> {
  using type = std::uniform_real_distribution<T>;
};
} // namespace detail

template <typename T>
  requires std::floating_point<T> || std::integral<T>
using rand_dist_t = detail::rand_dist<T>::type;

template <typename T>
  requires std::floating_point<T> || std::integral<T>
auto makeRandomVector(std::size_t size = 100,
                      T min = std::numeric_limits<T>::min(),
                      T max = std::numeric_limits<T>::max()) {
  thread_local std::mt19937 prng{std::random_device{}()};
  rand_dist_t<T> random_dist{min, max};

  std::vector<T> result;
  result.reserve(size);
  std::generate_n(std::back_inserter(result), size,
                  [&] { return random_dist(prng); });
  return result;
}

auto makeRandomString(std::size_t size) -> std::string {
  thread_local std::mt19937 prng{std::random_device{}()};
  std::uniform_int_distribution<short> dist{'a', 'z'};
  std::string retval;
  retval.reserve(size);
  std::generate_n(std::back_inserter(retval), size,
                  [&] { return static_cast<char>(dist(prng)); });
  return retval;
}

auto makeRandomVectorOfStrings(std::size_t num_strs, std::size_t str_len)
    -> std::vector<std::string> {
  std::vector<std::string> retval;
  retval.reserve(num_strs);
  std::generate_n(std::back_inserter(retval), num_strs,
                  [&] { return makeRandomString(str_len); });
  return retval;
}
