#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"
#include "oneapi/tbb.h"

#include <atomic>

void BM_par_red_naive(benchmark::State &state) {
  const auto max_threads = state.range(0);
  const auto guard = oneapi::tbb::global_control{
      oneapi::tbb::global_control::max_allowed_parallelism, max_threads};
  const int n = 1 << 24;
  const auto input = makeRandomVector<double>(n);
  const auto range = oneapi::tbb::blocked_range<int>{0, n};
  for (auto _ : state) {
    std::atomic<double> sum{0};
    oneapi::tbb::parallel_for(range, [&](const auto &r) {
      for (int i = r.begin(); i != r.end(); ++i)
        sum += input[i];
    });
    benchmark::DoNotOptimize(sum);
  }
  state.counters["Flops"] = benchmark::Counter{
      static_cast<double>(state.iterations()) * n, benchmark::Counter::kIsRate,
      benchmark::Counter::kIs1000};
}
BENCHMARK(BM_par_red_naive)->UseRealTime()->RangeMultiplier(2)->Range(1, 16);
BENCHMARK_MAIN();
