#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"

#include <algorithm>
#include <execution>
#include <ranges>
#include <thread>

void BM_stdpar(benchmark::State &state) {
  const auto input = makeRandomVectorOfStrings(state.range(0), state.range(1));
  auto output = std::vector<size_t>(input.size());
  const auto hash = std::hash<std::string>{};
  for (auto _ : state) {
    std::transform(std::execution::par_unseq, input.begin(), input.end(),
                   output.begin(), hash);
    benchmark::DoNotOptimize(output.data());
    benchmark::ClobberMemory();
  }
  if (!std::ranges::equal(
          output, input | std::views::transform(std::hash<std::string>{})))
    throw std::runtime_error{"Incorrect result"};
  state.SetBytesProcessed(state.range(0) * state.range(1) * state.iterations());
}
BENCHMARK(BM_stdpar)->UseRealTime()->RangeMultiplier(4)->Ranges(
    {{1 << 8, 1 << 14}, {1 << 8, 1 << 14}});
BENCHMARK_MAIN();
