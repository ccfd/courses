#include "benchmark/benchmark.h"

void BM_inc(benchmark::State &state) {
  const int n = state.range(0);
  for (auto _ : state) {
    volatile unsigned a = 0;
    for (int i = 0; i != n; ++i)
      ++a;
  }
  state.counters["increments"] = benchmark::Counter{
      static_cast<double>(state.iterations()) * n, benchmark::Counter::kIsRate,
      benchmark::Counter::kIs1000};
}
BENCHMARK(BM_inc)->Arg(1 << 12);
BENCHMARK_MAIN();
