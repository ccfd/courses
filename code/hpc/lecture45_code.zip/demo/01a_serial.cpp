#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"

void BM_serial(benchmark::State &state) {
  const auto input = makeRandomVectorOfStrings(state.range(0), state.range(1));
  auto output = std::vector<size_t>(input.size());
  const auto hash = std::hash<std::string>{};
  for (auto _ : state) {
    std::ranges::transform(input, output.begin(), hash);
    benchmark::DoNotOptimize(output.data());
    benchmark::ClobberMemory();
  }
  state.SetBytesProcessed(state.range(0) * state.range(1) * state.iterations());
}
BENCHMARK(BM_serial)->RangeMultiplier(4)->Ranges({{1 << 8, 1 << 14},
                                                  {1 << 8, 1 << 14}});
BENCHMARK_MAIN();
