#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"

#include <algorithm>
#include <latch>
#include <ranges>
#include <thread>

struct Counter {
  volatile int counter = 0;
};

void BM_false_sharing(benchmark::State &state) {
  const int num_threads = state.range(0);
  constexpr int num_incs = 1'000'000;
  auto threads = std::vector<std::thread>(num_threads);
  for (auto _ : state) {
    state.PauseTiming();
    auto counters = std::vector<Counter>(num_threads);
    auto latch_start = std::latch{num_threads + 1};
    auto latch_finish = std::latch{num_threads + 1};
    for (auto &&[i, thr] : threads | std::views::enumerate)
      thr = std::thread{[&, i] {
        latch_start.arrive_and_wait();
        auto &global_counter = counters[i].counter;
        for (int local_counter = 0; local_counter != num_incs; ++local_counter)
          global_counter = local_counter;
        latch_finish.count_down();
      }};
    latch_start.arrive_and_wait();
    state.ResumeTiming();
    latch_finish.arrive_and_wait();
    benchmark::DoNotOptimize(counters.data());
    benchmark::ClobberMemory();
    state.PauseTiming();
    for (auto &thr : threads)
      thr.join();
    state.ResumeTiming();
  }
  state.counters["increments"] = benchmark::Counter{
      static_cast<double>(state.iterations()) * num_incs,
      benchmark::Counter::kIsRate, benchmark::Counter::kIs1000};
}
BENCHMARK(BM_false_sharing)->UseRealTime()->RangeMultiplier(2)->Range(1, 16);
BENCHMARK_MAIN();
