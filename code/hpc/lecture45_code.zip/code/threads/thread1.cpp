#include <cmath>
#include <iostream>
#include <thread>
#include <vector>
#include <unistd.h>
 
using namespace std;
 
void foo() 
{
  vector<double> v(100000000);
for(int i=0; i<v.size(); ++i)
{
	v[i] = sin(i*M_PI*pow(4.5, i/20.0));
}


for(int i=0; i<10; ++i)
  {
  	cout << "foo says: foo sleeps " << i << endl;
  	sleep ( 2 );
  }
  std::cout << "foo completed.\n";
}

void bar(int x)
{
  for(int i=0; i<10; ++i)
  {
  	cout << "bar says: x=" << x << " bar sleeps " << i << endl;
  	sleep ( 1 );
  }
  std::cout << "bar completed.\n";
}

int main() 
{
  std::thread first (foo);     // spawn new thread that calls foo()
  std::thread second (bar,9);  // spawn new thread that calls bar(0)

  cout << "main thread says: foo and bar now execute concurrently..." << endl;

  // synchronize threads:
  first.join();                // pauses until first finishes
  second.join();               // pauses until second finishes

  std::cout << "foo and bar completed.\n";

  return 0;
}
