#include <atomic>
#include <iostream>
#include <thread>

int main()
{
 std::atomic<int> a{0};
 const auto inc = [&] { for(int i = 0; i < 100000000; ++i) ++a; };
 std::thread t1(inc);
 std::thread t2(inc);
 t1.join();
 t2.join();
 std::cout << a.load() << '\n';
}
