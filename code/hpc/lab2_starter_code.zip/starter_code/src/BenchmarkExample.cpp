#include "MakeRandomVector.hpp"
#include "benchmark/benchmark.h"

#include <cmath>

static void BM_compute_sine(benchmark::State& state)
{
    const auto input  = makeRandomVector< double >(100, -3.14, 3.14);
    auto       output = input;
    for (auto _ : state)
    {
        std::transform(input.cbegin(), input.cend(), output.begin(), [](auto x) { return std::sin(x); });
        benchmark::DoNotOptimize(output.data());
        benchmark::ClobberMemory();
    }
    state.SetBytesProcessed(state.iterations() * input.size() * sizeof(double));
}
BENCHMARK(BM_compute_sine)->Name("Compute sine");
