#include "GenerateMesh.hpp"

#include "benchmark/benchmark.h"

#include <iostream>

static auto computeLocalProduct(const std::vector< double >& coords, const std::vector< double >& lhs_local)
    -> std::vector< double >
{
    const auto dx   = coords[2] - coords[0];
    const auto dy   = coords[3] - coords[1];
    const auto dx2  = dx * dx;
    const auto dy2  = dy * dy;
    const auto dxdy = dx * dy;

    std::vector< std::vector< double > > K(4, std::vector< double >(4));
    K[0][0] = dx2;
    K[0][1] = dxdy;
    K[0][2] = -dx2;
    K[0][3] = -dxdy;
    K[1][0] = dxdy;
    K[1][1] = dy2;
    K[1][2] = -dxdy;
    K[1][3] = -dy2;
    for (unsigned c = 2; c < 4; ++c)
        for (unsigned r = 0; r < 4; ++r)
            K[c][r] = -K[c - 2][r];

    std::vector< double > mult_result(4);
    for (unsigned c = 0; c < 4; ++c)
        for (unsigned r = 0; r < 4; ++r)
            mult_result[r] += K[c][r] * lhs_local[c];

    const auto     L = std::sqrt(dx2 + dy2);
    constexpr auto E = 210e9;
    constexpr auto A = 3.14 * 1e-2 * 1e-2;
    const auto     C = E * A / (L * L * L);
    for (auto& a : mult_result)
        a *= C;

    return mult_result;
}

template < typename Node >

static auto computeDofs(const std::array< Node, 2 >& nodes) -> std::vector< Node >
{
    const auto [n1, n2]      = nodes;
    std::vector< Node > dofs = {n1 * 2, n1 * 2 + 1, n2 * 2, n2 * 2 + 1};
    return dofs;
}

template < typename Node >
static auto gatherGlobal(const std::array< Node, 2 >& nodes, const std::vector< double >& lhs_global)
    -> std::vector< double >
{
    const auto            dofs = computeDofs(nodes);
    std::vector< double > vals(4);
    for (size_t i = 0; i < dofs.size(); ++i)
        vals[i] = lhs_global[dofs[i]];
    return vals;
}

template < typename Node >
static void
scatterLocal(const std::array< Node, 2 >& nodes, const std::vector< double >& vals, std::vector< double >& rhs_global)
{
    const auto dofs = computeDofs(nodes);
    for (unsigned i = 0; i < dofs.size(); ++i)
        rhs_global[dofs[i]] += vals[i];
}

template < typename Node >
static void processsElement(const std::array< Node, 2 >& nodes,
                            const std::vector< double >& x,
                            const std::vector< double >& y,
                            const std::vector< double >& lhs,
                            std::vector< double >&       rhs)
{
    const auto lhs_vals              = gatherGlobal(nodes, lhs);
    const auto [n1, n2]              = nodes;
    std::vector< double > coords     = {x[n1], y[n1], x[n2], y[n2]};
    const auto            local_prod = computeLocalProduct(coords, lhs_vals);
    scatterLocal(nodes, local_prod, rhs);
}

template < typename Node >
static void solution(const Mesh< Node >& mesh, const std::vector< double >& lhs, std::vector< double >& rhs)
{
    std::fill(rhs.begin(), rhs.end(), 0.);
    for (const auto& nodes : mesh.topology)
        processsElement(nodes, mesh.x, mesh.y, lhs, rhs);
}

static void BM_baseline(benchmark::State& state)
{
    // Mesh
    constexpr unsigned n_nodes_x = 8000, n_nodes_y = 1000, n_nodes = n_nodes_x * n_nodes_y;
    constexpr unsigned seed = 0xaf173e8au;
    const auto         mesh = generateMesh(n_nodes_x, n_nodes_y, seed);

    // Generate random left-hand side
    auto         lhs = std::vector< double >(2 * n_nodes);
    std::mt19937 prng{std::random_device{}()};
    auto         dist = std::uniform_real_distribution< double >{0., 42.};
    std::generate_n(lhs.begin(), 2 * n_nodes, [&] { return dist(prng); });

    // Right-hand side
    auto rhs = std::vector< double >(2 * n_nodes);

    // Run the benchmark
    for (auto _ : state)
    {
        solution(mesh, lhs, rhs);
        benchmark::DoNotOptimize(rhs.data());
        benchmark::ClobberMemory();
    }
    state.counters["Elements/s"] = benchmark::Counter{static_cast< double >(state.iterations() * mesh.topology.size()),
                                                      benchmark::Counter::kIsRate,
                                                      benchmark::Counter::kIs1000};
}

BENCHMARK(BM_baseline)->Name("Baseline")->Unit(benchmark::kSecond);
