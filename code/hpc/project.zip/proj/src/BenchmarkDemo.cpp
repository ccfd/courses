#include "benchmark/benchmark.h"
#include "MakeRandomVector.hpp"

#include <chrono>
#include <thread>
#include <cmath>

void bench_noop(benchmark::State& state)
{
    for(auto _ : state)
        ;
}
BENCHMARK(bench_noop);


void bench_wait(benchmark::State& state)
{
    using namespace std::chrono_literals;
    for(auto _ : state)
        std::this_thread::sleep_for(1s);
}
BENCHMARK(bench_wait)->Unit(benchmark::kSecond)->Name("Wait 1 second");

BENCHMARK_MAIN();
