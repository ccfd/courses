---
number: 9
course: Programowanie Obiektowe w c++
material: Cheat Sheat
author: ccfd-class
---

# Cheat Sheat

Selected materials are given here. To ease learning.

## UML Class Diagram

![uml class](figures/cpp_cheat_sheat/uml-class-cheat-sheat.jpg)

![uml class](figures/cpp_cheat_sheat/UML02.png)

![uml class](figures/cpp_cheat_sheat/UML03.png)
